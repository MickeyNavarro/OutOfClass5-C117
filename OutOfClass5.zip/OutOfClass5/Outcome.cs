﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Almicke "Mickey" Navarro 
//CST117 
//Date: April 27, 2018
//This is my own work.
namespace OutOfClass5
{
    public partial class Outcome : Form
    {
        public Outcome()
        {
            InitializeComponent();
        }


    }
}
